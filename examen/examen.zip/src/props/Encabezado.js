import React from 'react'

export default function Encabezado() {
  return (
    <div className="row">
        <div className="col-12">
            <div className="section-title mb-4">
                <h2 className="mb-3">Choose Your Subscription Plan</h2>
                <p>Demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee idea of
                    denouncing pleasure and praising</p>
            </div>
        </div>
    </div>
  )
}
